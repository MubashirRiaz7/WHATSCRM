<?php
/**
* ConfigurationRepositoryInterface.php - Interface file
*
* This file is part of the Configuration component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Configuration\Interfaces;

interface ConfigurationRepositoryInterface
{
}
