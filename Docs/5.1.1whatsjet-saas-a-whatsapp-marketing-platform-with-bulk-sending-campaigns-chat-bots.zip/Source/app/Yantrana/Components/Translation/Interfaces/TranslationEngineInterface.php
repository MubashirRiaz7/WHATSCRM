<?php
/**
* TranslationEngineInterface.php - Interface file
*
* This file is part of the Translation component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Translation\Interfaces;

interface TranslationEngineInterface
{
}
