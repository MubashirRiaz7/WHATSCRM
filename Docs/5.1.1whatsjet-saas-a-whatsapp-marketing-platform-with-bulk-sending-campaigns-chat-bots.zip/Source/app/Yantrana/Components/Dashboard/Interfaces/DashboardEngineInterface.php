<?php
/**
* DashboardEngineInterface.php - Interface file
*
* This file is part of the Dashboard component.
*-----------------------------------------------------------------------------*/

namespace App\Yantrana\Components\Dashboard\Interfaces;

interface DashboardEngineInterface
{
}
