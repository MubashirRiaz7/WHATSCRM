<?php

// WARNING!! DO NOT CHANGE HERE
return [
    'product_name' => 'lw-whatsjet',
    'product_uid' => 'wa0e2ee6-e08b-491f-b9c0-fff206b774da',
    'your_email' => '',
    'registration_id' => '',
    'name' => 'WhatsJet',
    'version' => '5.1.1',
    'app_update_url' => env('APP_UPDATE_URL', 'https://product-central.livelyworks.net'),
];
