@extends('errors::minimal')

@section('title', __tr('Page Expired'))
@section('code', '419')
@section('message', __tr('Page Expired'))
